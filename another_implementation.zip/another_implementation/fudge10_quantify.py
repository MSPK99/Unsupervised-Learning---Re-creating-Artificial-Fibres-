import os
import numpy as np
import pandas as pd
from skimage.io import imread
from skimage.measure import label, regionprops
from skimage.color import rgb2gray
from scipy import ndimage as ndi

def extract_basic_features(region):
    """Extract basic features such as length, diameter, perimeter, and solidity."""
    length = region.major_axis_length
    diameter = region.minor_axis_length
    perimeter = region.perimeter
    solidity = region.solidity
    
    return length, diameter, perimeter, solidity

# Set the directory containing the segmented images
segmented_dir = 'labeled_fibers'

# Initialize a list to store the data
data = []

# Iterate over the images in the directory
for filename in os.listdir(segmented_dir):
    if filename.endswith('.png'):
        print(f'Processing {filename}...')
        try:
            # Load the image
            img = imread(os.path.join(segmented_dir, filename))
            
            # Convert to grayscale if needed
            if len(img.shape) == 3:
                img = rgb2gray(img)

            # Label the image
            label_image = label(img > 0)

            # Compute the properties of the labeled regions
            regions = regionprops(label_image)

            # Extract basic features for each fiber
            for i, region in enumerate(regions):
                length, diameter, perimeter, solidity = extract_basic_features(region)

                fiber_data = {
                    'Image': filename, 
                    'Fibre ID': i, 
                    'Length': length, 
                    'Diameter': diameter, 
                    'Perimeter': perimeter, 
                    'Solidity': solidity
                }
                
                data.append(fiber_data)

            # Compute fiber density and connectivity
            fiber_density = len(regions) / (img.shape[0] * img.shape[1])
            connectivity = len(ndi.label(img)[1]) / len(regions)
            print(f'Fiber density in {filename}: {fiber_density}')
            print(f'Connectivity in {filename}: {connectivity}')

        except Exception as e:
            print(f"Error processing {filename}: {e}")

# Convert the list of data to a DataFrame
results_df = pd.DataFrame(data)

# Save the results to an Excel file
results_df.to_excel('fiber_properties_simplified.xlsx', index=False)
print('Saved the results to fiber_properties_simplified.xlsx.')
