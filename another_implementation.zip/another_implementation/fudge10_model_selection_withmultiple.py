# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load the data
data = pd.read_excel('feature_vectors_with_labels.xlsx')

# Drop the 'Image' column
X = data.drop(columns=['Image', 'Label'])

# Convert labels into numerical values
le = LabelEncoder()
y = le.fit_transform(data['Label'])

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Define classifiers
classifiers = {
    "SVM": SVC(random_state=42),
    "Random Forest": RandomForestClassifier(random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42)
}

# Train and evaluate classifiers
results = {}
for name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    predictions = clf.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions)
    
    results[name] = {
        "Accuracy": accuracy,
        "Classification Report": report
    }

# Print the performance of each classifier
for name, metrics in results.items():
    print(f"{name} - Accuracy: {metrics['Accuracy']*100:.2f}%")
    print(metrics['Classification Report'])
    print("----------------------")

# Plot feature importances for RandomForest
if "Random Forest" in classifiers:
    rf = classifiers["Random Forest"]
    importances = rf.feature_importances_
    indices = np.argsort(importances)[::-1]

    plt.figure(figsize=(12,8))
    plt.title("Feature Importances (Random Forest)")
    plt.barh(X.columns[indices][:10], importances[indices][:10], align="center", color='skyblue')
    plt.xlabel('Relative Importance')
    plt.gca().invert_yaxis()
    plt.show()
