
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the feature vectors data
feature_vectors = pd.read_excel("feature_vectors_with_labels.xlsx")

# Define features for visualization
features_to_visualize = ['Length_mean', 'Diameter_mean', 'Perimeter_mean', 'Solidity_mean']

# Set up the figure and axes
fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(15, 10))
axes = axes.ravel()

# Plot boxplots for each feature
for i, feature in enumerate(features_to_visualize):
    sns.boxplot(data=feature_vectors, x='Label', y=feature, ax=axes[i])
    axes[i].set_title(f'Distribution of {feature.split("_")[0]} by Label')
    axes[i].set_ylabel(feature.split("_")[0])
    axes[i].set_xlabel('Label')

plt.tight_layout()
plt.show()
