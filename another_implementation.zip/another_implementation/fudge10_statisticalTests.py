

# need to alter this code 


import pandas as pd
import scipy.stats as stats

# Load the data
feature_vectors = pd.read_excel('feature_vectors_with_labels.xlsx')

# List of features to conduct ANOVA on
features_to_test = ['Length_mean', 'Diameter_mean', 'Perimeter_mean', 'Solidity_mean']

# Create an empty dataframe to store ANOVA results
anova_results = pd.DataFrame(columns=['Feature', 'F-Statistic', 'p-value'])

# Conduct ANOVA for each feature
for feature in features_to_test:
    # Create groups based on image labels
    groups = [feature_vectors[feature][feature_vectors['Label'] == label] for label in feature_vectors['Label'].unique()]
    
    # Perform one-way ANOVA
    f_statistic, p_value = stats.f_oneway(*groups)
    
    # Append the results to the dataframe
    anova_results = anova_results.append({'Feature': feature, 'F-Statistic': f_statistic, 'p-value': p_value}, ignore_index=True)

print(anova_results)
