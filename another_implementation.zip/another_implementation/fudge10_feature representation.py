
# manually adjusted few labels 

import pandas as pd
import re

# Load the extracted features
file_path = 'fiber_properties_with_labels_cleaned.xlsx'
features = pd.read_excel(file_path)

# Remove the 'labeled_fibers_' prefix and '.png' suffix from the 'Image' column
features['Image'] = features['Image'].str.replace('labeled_fibers_', '').str.replace('.png', '')

# Group the features by image
grouped = features.groupby('Image')

# Compute statistical summaries of the features
summaries = grouped.agg(['mean', 'median', 'std', 'min', 'max', 'var'])

# Flatten the multi-level column index
summaries.columns = ['_'.join(col) for col in summaries.columns]

# Add a new column for the labels
summaries['Label'] = ''

# Iterate over the images in the DataFrame
for image in summaries.index:
    # Remove the date from the image name
    image_no_date = re.sub(r'\d{2}_\d{2}_\d{4}_', '', image)
    
    # Extract the label from the image name
    label = image_no_date.split('_')[0]
    
    # Assign the label to the corresponding image in the DataFrame
    summaries.loc[image, 'Label'] = label

# Save the feature vectors to a new Excel file
output_path = 'feature_vectors.xlsx'
summaries.to_excel(output_path)

print(f'Saved the feature vectors to {output_path}.')
