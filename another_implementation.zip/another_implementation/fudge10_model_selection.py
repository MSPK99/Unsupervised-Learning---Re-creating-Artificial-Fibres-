'''
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report, confusion_matrix

# Load the data
data = pd.read_excel('feature_vectors_with_labels.xlsx')

# Drop the 'Image' column
X = data.drop(columns=['Image', 'Label'])

# Convert labels into numerical values
le = LabelEncoder()
y = le.fit_transform(data['Label'])

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Define classifiers
classifiers = {
    "SVM": SVC(random_state=42),
}

# Train and evaluate classifiers
results = {}
for name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    predictions = clf.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions)
    
    results[name] = {
        "Accuracy": accuracy,
        "Classification Report": report
    }

# Print the performance of each classifier
for name, metrics in results.items():
    print(f"{name} - Accuracy: {metrics['Accuracy']*100:.2f}%")
    print(metrics['Classification Report'])
    print("----------------------")
'''



import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report

# Load the data
data = pd.read_excel('feature_vectors_with_labels.xlsx')

# Drop the 'Image' column
X = data.drop(columns=['Image', 'Label'])

# Convert labels into numerical values
le = LabelEncoder()
y = le.fit_transform(data['Label'])

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Define classifiers with potential hyperparameters
classifiers = {
    "SVM": SVC(random_state=42),
    "Random Forest": RandomForestClassifier(random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42)
}

# Potential hyperparameters for grid search
param_grids = {
    "SVM": {
        'C': [0.1, 1, 10, 100],
        'gamma': ['scale', 'auto'],
        'kernel': ['linear', 'rbf']
    }
}

# Train, optimize (using grid search for SVM), and evaluate classifiers
results = {}
for name, clf in classifiers.items():
    if name in param_grids:
        # Use GridSearchCV for hyperparameter tuning
        grid_search = GridSearchCV(clf, param_grids[name], cv=5)
        grid_search.fit(X_train, y_train)
        best_clf = grid_search.best_estimator_
    else:
        best_clf = clf
        best_clf.fit(X_train, y_train)
    
    predictions = best_clf.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions)
    
    results[name] = {
        "Accuracy": accuracy,
        "Classification Report": report
    }

# Print the performance of each classifier
for name, metrics in results.items():
    print(f"{name} - Accuracy: {metrics['Accuracy']*100:.2f}%")
    print(metrics['Classification Report'])
    print("----------------------")

# Feature Importance for Random Forest
if "Random Forest" in classifiers:
    importances = classifiers["Random Forest"].feature_importances_
    features = X.columns
    feature_importances = pd.DataFrame({"Feature": features, "Importance": importances}).sort_values(by="Importance", ascending=False)
    print("Feature Importances for Random Forest:")
    print(feature_importances)
